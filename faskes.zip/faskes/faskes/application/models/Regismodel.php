<?php
class Regismodel extends CI_Model{
   // query database, ngambil data table dari phpmyadmin
   public function getAll(){
   $query = $this->db->get('users');
   return $query;
}
public function getById($id){
   $query = $this->db->get_where('users', array('id' => $id));
   return $query;
}
public function simpan($data){
   $sql = "INSERT INTO users (username,password,email,role) VALUES (?,?,?,?)";
   
   $this->db->query($sql, $data);

   $insert_id = $this->db->insert_id();
   return $this->findById($insert_id);
}
   public function findById($id){
       $query = $this->db->get_where('users', array('id'=>$id));
       return $query->row();
   }
   public function update($data){
       // update table kuliner
       $sql = "UPDATE users SET username=?,password=?,email=?,role=? WHERE id=?";
       $this->db->query($sql, $data);
   }
   public function delete($data){
       // update table kuliner
       $sql = "DELETE FROM users WHERE id=?";
       $this->db->query($sql, $data);
   }
}
?>