<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <title>FASKES | LOGIN</title>
    <!-- Load File CSS Bootstrap  -->
    <link rel="stylesheet" href="<?php echo base_url('dist/css/adminlte.min.css')?>">
    
</head>
<body>
    <div class="container">
        <div class="form-signin">
        <center></center>
        <center> <h3 class="form-signin-heading"> Login Faskes </h3> </center>
            <?php
            /*
            * Variabel $contentnya diambil dari core MY_Controller
            * (application/core/MY_Controller.php)
            * */
            echo $contentnya;
            ?>
        </div>
    </div>
</body>
</html>