  <!-- Content Wrapper. Contains page content -->
  <link rel="stylesheet" href="<?php echo base_url('dist/css/adminlte.min.css')?>">
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Komentar</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url('index.php/home/index')?>">Home</a></li>
              <li class="breadcrumb-item active">Komentar</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">Komentar</h3>

          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
              <i class="fas fa-minus"></i>
            </button>
            <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
              <i class="fas fa-times"></i>
            </button>
          </div>
        </div>
        <script>
function hapusDosen(pesan){
    if (confirm(pesan)){
        return true;
    }
    else{
        return false;
    }
}
</script>
        <div class="card-body">
        <table class="table table-dark table-responsive">
<thead>
<tr>
<th>No</th>
<th>Tanggal</th>
<th>Isi</th>
<th>User Id</th>
<th>Faskes Id</th>
<th>Nilai Rating Id</th>
</tr>
</thead>
<tbody>
<?php 
$nomor=1;
foreach ($komentar->result() as $row) {
    echo '<tr><td>'.$nomor.'</td>';
    echo '<td>'.$row->tanggal .'</td>';
    echo '<td>'.$row->isi .'</td>';
    echo '<td>'.$row->users_id .'</td>';
    echo '<td>'.$row->faskes_id .'</td>';
    echo '<td>'.$row->nilai_rating_id .'</td>';
    echo '</tr>';
    $nomor++;
} ?>
</tbody>
</table>
<hr>
        </div>
        <!-- /.card-body -->
        <div class="card-footer">
          Created By Reva Diaz Since 2022
        </div>
        <!-- /.card-footer-->
      </div>
      <!-- /.card -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->