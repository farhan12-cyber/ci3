  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Detail Faskes</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Detail Faskes</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">Detail Faskes</h3>

          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
              <i class="fas fa-minus"></i>
            </button>
            <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
              <i class="fas fa-times"></i>
            </button>
          </div>
        </div>
        <script>
function hapusDosen(pesan){
    if (confirm(pesan)){
        return true;
    }
    else{
        return false;
    }
}
</script>
        <div class="card-body">
        <table class="table table-dark table-responsive">
<thead>
<tr>
<th>No</th>
<th>ID</th>
<th>Nama</th>
<th>Alamat</th>
<th>Jenis_id</th>
<th>Deskripsi</th>
<th>Skor Rating</th>
<th>Kecamatan_Id</th>
<th>Kecamatan_Id</th>
<th>Jumlah Dokter</th>
<th>Jumlah Pegawai</th>
</tr>
</thead>
<tbody>
<?php 
$nomor=1;
    echo '<tr><td>'.$nomor.'</td>';
    echo '<td>'.$faskes->id .'</td>';
    echo '<td>'.$faskes->nama .'</td>';
    echo '<td>'.$faskes->alamat .'</td>';
    echo '<td>'.$faskes->jenis_id .'</td>';
    echo '<td>'.$faskes->deskripsi .'</td>';
    echo '<td>'.$faskes->skor_rating .'</td>';
    echo '<td>'.$faskes->kecamatan_id .'</td>';
    echo '<td>'.$faskes->website .'</td>';
    echo '<td>'.$faskes->jumlah_dokter .'</td>';
    echo '<td>'.$faskes->jumlah_pegawai .'</td>';
    echo '</tr>';
    $nomor++;
?>
</tbody>
</table>
<div class="col-sm-4">
<hr>
<img src="<?=base_url()?>uploads/<?=$faskes->id?>.jpg" class="" width="300"/>
  <!-- $filegambar = base_url('uploads/'.$faskes->foto1);
  $array = get_headers($filegambar);
  $string = $array[0];
  if(strpos($string,"200"))
  {
    echo '<img src="'.$filegambar.'" alt="foto" class="img-thumbnail" width="100%/>';
  }else{
    echo '<img src="'.base_url('uploads/noimage.jpg').'" class="img-thumbnail" alt="foto" width="70%"/>';
  } -->

    Nama Foto : <?= $faskes->foto1?>
    <br>
  <?php
  echo form_open_multipart('faskes/upload');
  ?>
  <input type="hidden" name="id" value="<?=$faskes->id?>"/>
  <input type="file" name="fotomhs" size="20"/>
<hr>
  <input type="submit" class="btn btn-primary" value="upload" />
</form>
</div>
        </div>
        <!-- /.card-body -->
        <div class="card-footer">
          Created By Reva Diaz Since 2022
        </div>
        <!-- /.card-footer-->
      </div>
      <!-- /.card -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->