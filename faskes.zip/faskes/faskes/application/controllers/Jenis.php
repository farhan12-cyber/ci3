<?php
class Jenis extends CI_Controller{
    public function index(){
        $this->load->model('jenis_model', 'jenis_faskes');
        $data['list_jenis'] = $this->jenis_faskes->getAll();
            // kirim ke view
            $this->load->view('layouts/index');
            $this->load->view('jenis/index', $data);
            $this->load->view('layouts/footer');
    }
    public function form() {
        // kirim ke view
        $this->load->view('layouts/index');
        $this->load->view('jenis/form');
        $this->load->view('layouts/footer');
}
public function save(){
    $this->load->model('jenis_model', 'jenis_faskes');
    $_nama = $this->input->post('nama');
    $_idedit = $this->input->post('idedit');

    $data_jenis['nama']=$_nama;//?2

    if(!empty($_idedit)){// update
        $data_jenis['id']=$_idedit;//?3
        $this->jenis_faskes->update($data_jenis);
    }else{//data baru
        $this->jenis_faskes->simpan($data_jenis);
    }
    redirect('jenis','refresh');
}
public function edit($id){
    $this->load->model('jenis_model', 'jenis_faskes');
    $obj_jenis = $this->jenis_faskes->findById($id);
    $data['objjenis']=$obj_jenis;
        // kirim ke view
        $this->load->view('layouts/index');
        $this->load->view('jenis/edit', $data);
        $this->load->view('layouts/footer');
}
public function delete($id){
    $this->load->model('jenis_model','jenis_faskes');
    $data_jenis['id']=$id;
    $this->jenis_faskes->delete($data_jenis);
    redirect('jenis','refresh');
}
}
?>