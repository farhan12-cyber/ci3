<?php
class Kecamatan extends CI_Controller{
    public function index(){
        $this->load->model('kecamatan_model', 'kecamatan');
        $data['list_kecamatan'] = $this->kecamatan->getAll();
            // kirim ke view
            $this->load->view('layouts/index');
            $this->load->view('kecamatan/index', $data);
            $this->load->view('layouts/footer');
    }
    public function form() {
        // kirim ke view
        $this->load->view('layouts/index');
        $this->load->view('kecamatan/form');
        $this->load->view('layouts/footer');
}
public function save(){
    $this->load->model('kecamatan_model', 'kecamatan');
    $_nama = $this->input->post('nama');
    $_idedit = $this->input->post('idedit');

    $data_kecamatan['nama']=$_nama;//?2

    if(!empty($_idedit)){// update
        $data_kecamatan['id']=$_idedit;//?3
        $this->kecamatan->update($data_kecamatan);
    }else{//data baru
        $this->kecamatan->simpan($data_kecamatan);
    }
    redirect('kecamatan','refresh');
}
public function edit($id){
    $this->load->model('kecamatan_model', 'kecamatan');
    $obj_kecamatan = $this->kecamatan->findById($id);
    $data['objkecamatan']=$obj_kecamatan;
        // kirim ke view
        $this->load->view('layouts/index');
        $this->load->view('kecamatan/edit', $data);
        $this->load->view('layouts/footer');
}
public function delete($id){
    $this->load->model('kecamatan_model','kecamatan');
    $data_kecamatan['id']=$id;
    $this->kecamatan->delete($data_kecamatan);
    redirect('kecamatan','refresh');
}
}
?>