<?php
class Nilai extends CI_Controller{
    public function index(){
        $this->load->model('nilai_model', 'nilai_rating');
        $data['list_nilai'] = $this->nilai_rating->getAll();
            // kirim ke view
            $this->load->view('layouts/index');
            $this->load->view('nilai/index', $data);
            $this->load->view('layouts/footer');
    }
    public function form() {
        // kirim ke view
        $this->load->view('layouts/index');
        $this->load->view('nilai/form');
        $this->load->view('layouts/footer');
}
public function save(){
    $this->load->model('nilai_model', 'nilai_rating');
    $_nama = $this->input->post('nama');
    $_idedit = $this->input->post('idedit');

    $data_nilai['nama']=$_nama;//?2

    if(!empty($_idedit)){// update
        $data_nilai['id']=$_idedit;//?3
        $this->nilai_rating->update($data_nilai);
    }else{//data baru
        $this->nilai_rating->simpan($data_nilai);
    }
    redirect('nilai','refresh');
}
public function edit($id){
    $this->load->model('nilai_model', 'nilai_rating');
    $obj_nilai = $this->nilai_rating->findById($id);
    $data['objnilai']=$obj_nilai;
        // kirim ke view
        $this->load->view('layouts/index');
        $this->load->view('nilai/edit', $data);
        $this->load->view('layouts/footer');
}
public function delete($id){
    $this->load->model('nilai_model','nilai_rating');
    $data_nilai['id']=$id;
    $this->nilai_rating->delete($data_nilai);
    redirect('nilai','refresh');
}
}
?>