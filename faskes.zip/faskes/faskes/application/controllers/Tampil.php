<?php
class Tampil extends CI_Controller{
public function index()
    {
        $this->load->model('faskes_model');
        $faskes = $this->faskes_model->getAll();
        $data['faskes'] = $faskes;
        $this->load->view('faskes/tampil', $data);
    }
    public function komentar(){
        // load model
        $this->load->model('komentar_model');
        $matkul = $this->komentar_model->getAll();
        $data['komentar'] = $matkul;
        $this->load->view('komentar/tampil', $data);

}
}
?>