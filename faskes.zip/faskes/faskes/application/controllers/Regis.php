<?php
class Regis extends CI_Controller {
    public function index() {
        $this->load->model('regismodel', 'users');
        $data['list_users'] = $this->users->getAll();
            // kirim ke view
            $this->load->view('regis/index', $data);
    }
    public function form() {
            // kirim ke view
            $this->load->view('regis/form');
    }
    public function save(){
        $this->load->model('regismodel', 'users');
        $_username = $this->input->post('username');
        $_password = $this->input->post('password');
        $_email = $this->input->post('email');
        $_role = $this->input->post('role');
        $_idedit = $this->input->post('idedit');
    
        $data_users['username']=$_username;//?2
        $data_users['password']=$_password;//?2
        $data_users['email']=$_email;//?2
        $data_users['role']=$_role;//?2
    
        if(!empty($_idedit)){// update
            $data_users['id']=$_idedit;//?3
            $this->users->update($data_users);
        }else{//data baru
            $this->users->simpan($data_users);
        }
        redirect('regis','refresh');
        /*
        $data['list_dosen'] = $this->dosen->getAll();
            // kirim ke view
            $this->load->view('layouts/header');
            $this->load->view('dosen/index', $data);
            $this->load->view('layouts/footer'); */
    }
    public function edit($id){
        $this->load->model('regismodel', 'users');
        $obj_users = $this->users->findById($id);
        $data['objusers']=$obj_users;
            // kirim ke view
            $this->load->view('regis/edit', $data);
    }
    public function delete($id){
        $this->load->model('regismodel','users');
        $data_users['id']=$id;
        $this->users->delete($data_users);
        redirect('regis','refresh');
    }
}

?>