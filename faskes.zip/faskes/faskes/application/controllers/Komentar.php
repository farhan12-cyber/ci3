<?php
class Komentar extends CI_Controller{
    public function index(){
        $this->load->model('komentar_model', 'komentar');
        $data['list_komentar'] = $this->komentar->getAll();
            // kirim ke view
            $this->load->view('layouts/index');
            $this->load->view('komentar/index', $data);
            $this->load->view('layouts/footer');
    }
    public function form() {
        // kirim ke view
        $this->load->view('layouts/index');
        $this->load->view('komentar/form');
        $this->load->view('layouts/footer');
}
public function save(){
    $this->load->model('komentar_model', 'komentar');
    $_tanggal = $this->input->post('tanggal');
    $_isi = $this->input->post('isi');
    $_user_id = $this->input->post('users_id');
    $_faskes_id = $this->input->post('faskes_id');
    $_nilai_rating_id = $this->input->post('nilai_rating_id');
    $_idedit = $this->input->post('idedit');

    $data_komentar['tanggal']=$_tanggal;
    $data_komentar['isi']=$_isi;
    $data_komentar['users_id']=$_user_id;//?2
    $data_komentar['faskes_id']=$_faskes_id;
    $data_komentar['nilai_rating_id']=$_nilai_rating_id;


    if(!empty($_idedit)){// update
        $data_komentar['id']=$_idedit;//?3
        $this->komentar->update($data_komentar);
    }else{//data baru
        $this->komentar->simpan($data_komentar);
    }
    redirect('komentar','refresh');
}
public function edit($id){
    $this->load->model('komentar_model', 'komentar');
    $obj_komentar = $this->komentar->findById($id);
    $data['objkomentar']=$obj_komentar;
        // kirim ke view
        $this->load->view('layouts/index');
        $this->load->view('komentar/edit', $data);
        $this->load->view('layouts/footer');
}
public function delete($id){
    $this->load->model('komentar_model','komentar');
    $data_komentar['id']=$id;
    $this->komentar->delete($data_komentar);
    redirect('komentar','refresh');
}
}
?>