<?php
class Home extends CI_Controller {
public function index(){
    // function render_backend tersebut dari file core/MY_Controller.php
    $this->load->view('page/index'); // load view home.php
  }
}
?>